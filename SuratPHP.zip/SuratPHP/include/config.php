<?php
$host     = "localhost";    // Nama host
$username = "root";         // Username database
$password = "";   // Password database
$database = "surat";   // Nama database
    